library(testthat)
library(xgxr)

test_check("xgxr")
