library(testthat)
library(xGx)

test_check("xGx")
