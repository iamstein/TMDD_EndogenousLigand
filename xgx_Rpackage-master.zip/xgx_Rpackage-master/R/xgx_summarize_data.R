#' Check data for various issues
#'
#' Calls \code{xgx_check_data} 
#' 
#' @export
xgx_summarize_data = function(...){
  xgx_check_data(...)
}
