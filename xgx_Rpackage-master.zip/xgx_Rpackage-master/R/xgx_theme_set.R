#' Sets the standard theme for xGx graphics
#'
#' xgx_theme_set
#' 
#' @export

xgx_theme_set <- function() {
  theme_set(theme_bw())
}