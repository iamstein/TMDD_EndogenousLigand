#' Append filenames to bottom of the plot 
#' 
#' \code{xgx_annotate_filenames} appends file details to the bottom of a plot using the plot caption option. 
#' File details to append include the parent directory, the path of the R script which generated the plot, 
#' and the path of the plot.
#' 
#'
#' @param dirs list containing directories and filenames.  It must contain five fields
#' \enumerate{
#' \item parent_dir  = Parent directory containing the Rscript and the Results folder
#' \item rscript_dir = Subdirectory ofparent_dir that contains the Rscript used to generate the figure
#' \item rscript_name= Name of the Rscript used to generate the figure
#' \item results_dir = Subdirectory ofparent_dir where the figure is stored
#' \item filename    = Filename
#' }
#' @param hjust horizontal justification of the caption
#' 
#' @return None
#' @export
#'
#' @examples#' 
#' library(ggplot2)  
#' dirs = list(Parent_dir   = "/your/parent/path/",
#'             rscript_dir  = "./Rscripts/",
#'             rscript_name = "Example.R",
#'             results_dir  = "./Results/",
#'             filename     = "your_file_name.png")
#' data = data.frame(x=1:1000,y=rnorm(1000))
#' ggplot(data=data,aes(x=x,y=y)) + 
#'   geom_point() +
#'   xgx_annotate_filenames(dirs)

xgx_annotate_filenames = function(dirs,hjust=0.5) {
  
  caption = xgx_dirs2char(dirs)
  return(list(
    labs(caption = caption),
    theme(plot.caption = element_text(hjust = hjust))
  ))
    
}